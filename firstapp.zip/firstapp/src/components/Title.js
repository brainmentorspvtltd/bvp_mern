import React from 'react';
export const Title = (props)=>{
    //let title = 'Ram';
    return (<h3>{props.msg}</h3>);
}