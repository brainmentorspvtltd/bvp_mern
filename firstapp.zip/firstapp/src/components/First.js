import React from 'react';
// export function First(){
//     return (<h1>I am the First Component</h1>);
// }
export const First = ()=>(<h1>I am the First Component (Arrow)</h1>);