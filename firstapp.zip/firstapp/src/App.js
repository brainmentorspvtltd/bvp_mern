import React from 'react';
import './App.css';
import { First } from './components/First';
import { Title } from './components/Title';
//export function App(){
  function App(){
  var message = 'Hello React-JS';
  const mystyle = {
    color:'green',
    backgroundColor:'yellow'

  }

  return (<div className='red'>
    <First/>
    <Title msg = 'Ram'/>
    <br/>
    <Title msg='Shyam'/>
    <h1 style={mystyle}>{message}</h1><h2>Hi React JS</h2></div>);
  //  return React.createElement('div',null,
  // React.createElement('h1',{class:'red'}, 'Hello React JS'),
  // React.createElement('h2',null, 'Hi React JS')
  // );
  //return (<h1><p>Hi</p></h1>);
  //return (<h1>Hello ReactJS</h1>)
  //return React.createElement('h1',null,'Hello ReactJS - Brain Mentors');
  //return React.createElement('h1',null,React.createElement('p',null,'Hi'));
}
export default App;