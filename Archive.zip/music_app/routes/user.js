const express = require('express');
const routes = express.Router();
routes.get('/',(request, response)=>{
    response.send('Welcome to the Home Page');
});
routes.get('/login', (request, response)=>{
    response.send('Login Done');
});
module.exports = routes;