const calc = require('./calc');
console.log(calc.add(10,20));