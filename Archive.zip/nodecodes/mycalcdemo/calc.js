const calc = {
    add(x,y){
        return x + y;
    },
    subtract(x,y){
        return x - y;
    }
}
module.exports = calc;
