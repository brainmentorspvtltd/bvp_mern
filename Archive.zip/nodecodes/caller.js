const calcObject = require('./moduledemo/calc');
console.log(calcObject.add(10,20));
console.log(calcObject.subtract(10,20));