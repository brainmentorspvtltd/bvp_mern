const chalk= require('chalk');
console.log(chalk.green('Hello Chalk'));
console.log(chalk.red.bold('Hi'));