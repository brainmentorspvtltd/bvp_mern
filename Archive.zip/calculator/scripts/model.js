const compute=expression=>eval(expression)
