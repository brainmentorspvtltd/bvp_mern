// salaryOperations.hra(); // Namespace.method
const salaryOperations = {
    // takeBasicSalary:function(){}
    basicSalary : 0,
    takeBasicSalary(basicSalary){
        this.basicSalary = basicSalary;
    },
    hra(){
        return this.basicSalary * 0.50;
    },
    da(){
        return this.basicSalary * 0.20;
    },
    ta(){
        return this.basicSalary * 0.10;

    },
    ma(){
        return this.basicSalary * 0.15;
    },
    pf(){
        return this.basicSalary * 0.05;
    },
    gs(){
        return this.basicSalary + this.hra() + this.da() + this.ta() + this.ma() ;
    },
    ns(){
        return this.gs() - this.pf() - this.tax();
    },
    tax(){
       return this.gs() * 0.10;
    }

}