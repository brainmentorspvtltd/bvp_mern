window.addEventListener('load',bindEvents);
function bindEvents(){
    //let button =document.getElementById('btn');
    let button = document.querySelector('#btn');
    button.addEventListener('click', input);
}
function input(){
    //let basicSalary = parseInt(document.getElementById('salarytxt').value);
    let basicSalary = parseInt(document.querySelector('#salarytxt').value);
    console.log('Basic Salary ', basicSalary);
    salaryOperations.takeBasicSalary(basicSalary);
    printResult();

}
function printResult(){
    let div = document.getElementById('output');
    for(let key in salaryOperations){
        if(key=='basicSalary' || key=='takeBasicSalary'){
            continue;
        }
        let result = salaryOperations[key]();
        createPTag(key.toUpperCase(), result);

    }
    // createPTag('HRA', salaryOperations.hra());
    // createPTag('DA ',salaryOperations.da());
    // createPTag('TA ',salaryOperations.ta());
    // createPTag('PF ',salaryOperations.pf());

    // let hra = salaryOperations.hra();
    // let pTag = document.createElement('p'); //<p></p>
    // pTag.innerText = hra; //<p>99</p>
    // div.appendChild(pTag); //<div><p>99</p></div>

}

function createPTag(label, val){
    let pTag = document.createElement('p');
    pTag.innerText = `${label} :: ${val}`;
    let div = document.querySelector('#output');
    div.appendChild(pTag);

}