import React from 'react';
export const Output = (props)=>{
    console.log("5. Output Component Called");
    return (<h2>Result is {props.result}</h2>)
}