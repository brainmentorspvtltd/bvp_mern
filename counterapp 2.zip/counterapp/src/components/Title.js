import React from 'react';
export const Title = ({title})=>{
    console.log("3. Title Component Called");
    return (<h1 className='alert-info text-center'>{title}</h1>);
}