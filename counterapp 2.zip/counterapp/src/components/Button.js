import React from 'react';
export const Button = (props)=>{
    console.log("4. Button Component Called");
    return (<button onClick={props.plusFn} className='btn btn-primary'>+</button>)
}