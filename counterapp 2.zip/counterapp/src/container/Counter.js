import React from 'react';
import { Button } from '../components/Button';
import { Output } from '../components/Output';
import {Title} from '../components/Title';
export class Counter extends React.Component {

    constructor(){
        super();
        console.log('1. Counter Constructor Call');
        this.value = 0;
        this.state = {plusValue:this.value};
    }
     plus (){
         console.log('6. Inside PLus ',this);
        this.value++;
        this.setState({plusValue:this.value}); // re-rendering
        console.log('Plus Called ', this.value);
    }
    render(){
        console.log('2. Counter render');
        return (
            <div className='container'>
            <Title title = "Counter App"/>
            <Button plusFn = {this.plus.bind(this)}/>
            <Output result={this.state.plusValue}/>
            </div>
        )
    }


}