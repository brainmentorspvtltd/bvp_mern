import React from 'react';

import { Counter } from './container/Counter';
const App=()=>{
  console.log('App render');
  return (

    <Counter/>
  )
}
export default App;