import React from 'react';
export const Title = ({title})=>{
    return (<h1 className='alert-info text-center'>{title}</h1>);
}