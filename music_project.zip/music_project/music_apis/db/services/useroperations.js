const userOperations = {
    login({userid, password}){
        if(userid == password){
            return "Welcome "+userid;
        }
        else{
            return "Invalid userid or password";
        }
    }
}
module.exports = userOperations;