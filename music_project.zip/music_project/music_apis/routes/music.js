const musicOperations = {
    getAlbums(){

    },
    getArtist(){

    },
    getPartySongs(){

    },
    getLatestSongs(){

    }
    
}
module.exports = musicOperations;