const express = require('express');
const routes = express.Router();
routes.get('/',(request, response)=>{
    response.send('Welcome to the Home Page');
});
routes.post('/login', (request, response)=>{
    let userObject = request.body;
    const userOperations = require('../db/services/useroperations');
    let result = userOperations.login(userObject);
   // response.json({message:result});
    response.status(200).json({message:result});
});
module.exports = routes;