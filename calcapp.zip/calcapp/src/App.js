import React from 'react'
import Calc from './containers/Calc'

const App=(props)=> {


  return (
    <>
      <Calc/>
    </>
  )
}
export default App;
