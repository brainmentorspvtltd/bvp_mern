import React from 'react'

export const Equal=(props)=> {


    return (
        <>
        <button onClick={props.computeit} className='btn btn-primary'>=</button>
        </>
    )
}
