import { Home } from "./containers/Home"

const App = ()=>{
  return (
    <div className='container'>
      <Home/>
    </div>
  );
}
export default App;